import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'notification_cards_widget.dart' show NotificationCardsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NotificationCardsModel extends FlutterFlowModel<NotificationCardsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
