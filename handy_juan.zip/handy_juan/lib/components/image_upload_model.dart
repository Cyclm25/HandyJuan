import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'image_upload_widget.dart' show ImageUploadWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ImageUploadModel extends FlutterFlowModel<ImageUploadWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
