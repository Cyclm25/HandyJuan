import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'chatbot_model.dart';
export 'chatbot_model.dart';

/// New Component Gen
class ChatbotWidget extends StatefulWidget {
  const ChatbotWidget({super.key});

  @override
  State<ChatbotWidget> createState() => _ChatbotWidgetState();
}

class _ChatbotWidgetState extends State<ChatbotWidget> {
  late ChatbotModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChatbotModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Container(
        width: 220.0,
        height: 220.0,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              blurRadius: 40.0,
              color: Color(0x6600C6FF),
              offset: Offset(
                0.0,
                0.0,
              ),
              spreadRadius: 20.0,
            )
          ],
          gradient: LinearGradient(
            colors: [Color(0x4C00C6FF), Color(0x4C00E5A0)],
            stops: [0.0, 1.0],
            begin: AlignmentDirectional(0.0, -1.0),
            end: AlignmentDirectional(0, 1.0),
          ),
          shape: BoxShape.circle,
        ),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 8.0, 8.0),
          child: Container(
            width: 220.0,
            height: 220.0,
            decoration: BoxDecoration(
              color: Color(0x00FFFFFF),
              shape: BoxShape.circle,
            ),
            child: Material(
              color: Colors.transparent,
              elevation: 4.0,
              shape: const CircleBorder(),
              child: Container(
                width: 200.0,
                height: 200.0,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Icon(
                    Icons.mic_rounded,
                    color: Color(0xFFD0D0D0),
                    size: 80.0,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
