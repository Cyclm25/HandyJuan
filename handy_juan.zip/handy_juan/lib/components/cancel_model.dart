import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'cancel_widget.dart' show CancelWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CancelModel extends FlutterFlowModel<CancelWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
