import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'booking_confirmation_widget.dart' show BookingConfirmationWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BookingConfirmationModel
    extends FlutterFlowModel<BookingConfirmationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
