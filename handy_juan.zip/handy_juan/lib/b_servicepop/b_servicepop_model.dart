import '/components/bservice_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'b_servicepop_widget.dart' show BServicepopWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BServicepopModel extends FlutterFlowModel<BServicepopWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Bservice component.
  late BserviceModel bserviceModel;

  @override
  void initState(BuildContext context) {
    bserviceModel = createModel(context, () => BserviceModel());
  }

  @override
  void dispose() {
    bserviceModel.dispose();
  }
}
