import '/components/bservice_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'b_servicepop_model.dart';
export 'b_servicepop_model.dart';

/// Create a page that is an overlay from the user account.
///
/// so on that overlay there would be two buttons in one row
///
/// header
/// "how soon do you want the service? "
///
/// 1st button
/// urgent call with a logo of urgent
///
/// ->when i clicked it, it will provide the contact number of the worker
/// basically it will just display the number of the worker
///
/// 2nd button
/// scheduled
/// ->when i clicked this it will redirect to another page with is a book a
/// service page
/// make all the containers align and the padding can breathe. adjust the font
/// size
class BServicepopWidget extends StatefulWidget {
  const BServicepopWidget({super.key});

  static String routeName = 'BServicepop';
  static String routePath = '/bServicepop';

  @override
  State<BServicepopWidget> createState() => _BServicepopWidgetState();
}

class _BServicepopWidgetState extends State<BServicepopWidget> {
  late BServicepopModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BServicepopModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0x80000000),
        body: SafeArea(
          top: true,
          child: wrapWithModel(
            model: _model.bserviceModel,
            updateCallback: () => safeSetState(() {}),
            child: BserviceWidget(),
          ),
        ),
      ),
    );
  }
}
