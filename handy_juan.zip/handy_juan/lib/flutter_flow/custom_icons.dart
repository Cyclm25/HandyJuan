import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _myFlutterAppFamily = 'MyFlutterApp';

  // MyFlutterApp
  static const IconData kurgentBolt =
      IconData(0xe800, fontFamily: _myFlutterAppFamily);
  static const IconData kscheduledCalendar =
      IconData(0xe801, fontFamily: _myFlutterAppFamily);
  static const IconData kcallIcon =
      IconData(0xe802, fontFamily: _myFlutterAppFamily);
}
