import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCEvSZqLXZqLQZh3ltl-YXGWyYrgbGOIWY",
            authDomain: "handyjuan-7042a.firebaseapp.com",
            projectId: "handyjuan-7042a",
            storageBucket: "handyjuan-7042a.firebasestorage.app",
            messagingSenderId: "825338494256",
            appId: "1:825338494256:web:c1c66b48a6c61773435cf5",
            measurementId: "G-P5M76GQWQX"));
  } else {
    await Firebase.initializeApp();
  }
}
