// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
Future<bool> validateLogin(
  String? email,
  String? password,
) async {
  // Check if null or empty
  if (email == null || email.trim().isEmpty) {
    return false;
  }
  if (password == null || password.trim().isEmpty) {
    return false;
  }

  // Strict email validation
  final emailRegex = RegExp(
    r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$',
  );
  if (!emailRegex.hasMatch(email.trim())) {
    return false;
  }

  // No spaces allowed in email
  if (email.contains(' ')) {
    return false;
  }

  // Password minimum 8 characters
  if (password.length < 8) {
    return false;
  }

  // Password must have at least 1 uppercase
  if (!password.contains(RegExp(r'[A-Z]'))) {
    return false;
  }

  // Password must have at least 1 lowercase
  if (!password.contains(RegExp(r'[a-z]'))) {
    return false;
  }

  // Password must have at least 1 number
  if (!password.contains(RegExp(r'[0-9]'))) {
    return false;
  }

  // Password must have at least 1 special character
  if (!password.contains(RegExp(r'[!@#\$%^&*(),.?":{}|<>]'))) {
    return false;
  }

  // No spaces allowed in password
  if (password.contains(' ')) {
    return false;
  }

  return true;
}
