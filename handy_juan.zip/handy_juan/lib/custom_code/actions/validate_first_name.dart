// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
//
/// Set your action name, define your arguments and return parameter, and then
/// add the boilerplate code using the green button on the right!
///
/// Set your action name, define your arguments and return parameter, and then
/// add the boilerplate code using the green button on the right!
Future<bool> validateFirstName(String? firstName) async {
  if (firstName == null || firstName.trim().isEmpty) {
    return false;
  }

  final cleanedName = firstName.trim();

  if (cleanedName.length < 2 || cleanedName.length > 30) {
    return false;
  }

  final nameRegex = RegExp(r"^[A-Za-zÑñ\s'-]+$");

  if (!nameRegex.hasMatch(cleanedName)) {
    return false;
  }

  if (cleanedName.contains(RegExp(r"\d"))) {
    return false;
  }

  return true;
}
