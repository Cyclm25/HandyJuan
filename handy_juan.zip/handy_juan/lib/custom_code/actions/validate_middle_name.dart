// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
//
Future<bool> validateMiddleName(String? middleName) async {
  // Check if empty or null
  if (middleName == null || middleName.trim().isEmpty) {
    return false;
  }

  final cleanedName = middleName.trim();

  // Length check
  if (cleanedName.length < 2 || cleanedName.length > 30) {
    return false;
  }

  // Allow only letters, spaces, hyphen, apostrophe
  final nameRegex = RegExp(r"^[a-zA-ZÑñ\s'-]+$");

  if (!nameRegex.hasMatch(cleanedName)) {
    return false;
  }

  return true;
}
