// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

String validateSignupForm(
  String firstName,
  String middleName,
  String lastName,
  String email,
  String password,
  String confirmPassword,
) {
  if (firstName.trim().isEmpty) {
    return 'First name is required';
  }

  if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(firstName.trim())) {
    return 'First name must contain letters only';
  }

  if (middleName.trim().isNotEmpty &&
      !RegExp(r'^[a-zA-Z\s]+$').hasMatch(middleName.trim())) {
    return 'Middle name must contain letters only';
  }

  if (lastName.trim().isEmpty) {
    return 'Last name is required';
  }

  if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(lastName.trim())) {
    return 'Last name must contain letters only';
  }

  if (email.trim().isEmpty) {
    return 'Email is required';
  }

  if (!RegExp(r'^[\w\.-]+@[\w\.-]+\.\w+$').hasMatch(email.trim())) {
    return 'Invalid email address';
  }

  if (password.isEmpty) {
    return 'Password is required';
  }

  if (password.length < 8) {
    return 'Password must be at least 8 characters';
  }

  if (password != confirmPassword) {
    return 'Passwords do not match';
  }

  return 'OK';
}
