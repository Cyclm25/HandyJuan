package com.mycompany.handyjuan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
